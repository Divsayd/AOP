package interfaces;
import model.Song;
public interface speakers {
    public String makeSound(Song song);
}
