package model;

public class ACcontrol {

    private String status;
    private int temp;

    public String getStatus() {
        return status;
    }

    public void setStatus(String title) {
        this.status = title;
    }

    public int getTemp() {
        return temp;
    }

    public void setTemp(int temp) {
        this.temp = temp;
    }
}
